#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp=${0%/*} ; wp=${wp:-.}

$wp/run.sh stop

systemctl disable transparent-proxy.service >/dev/null 2>&1

rm -f /etc/systemd/system/transparent-proxy.service

systemctl daemon-reload >/dev/null 2>&1

rm -rf $wp

