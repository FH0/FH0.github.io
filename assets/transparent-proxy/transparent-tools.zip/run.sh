#!/bin/bash
export PATH="/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
wp=${0%/*} ; wp=${wp:-.}

{
	pkill -f v2ray
	bash <(iptables -t nat -S | grep "transparent-proxy" | sed 's|^..|iptables -t nat -D|g')
	bash <(iptables -t mangle -S | grep "transparent-proxy" | sed 's|^..|iptables -t mangle -D|g')
	ip rule | grep " 1110" | sed 's|.*from|ip rule del from |g' | bash
	ip route flush table 1110
        if command -v systemctl;then
		systemctl disable transparent-proxy.service
	elif [ -e "/etc/rc.local" ];then
	        tmp_echo=$(grep -v "$(readlink -f $0)" /etc/rc.local)
        	echo "$tmp_echo" > /etc/rc.local
	fi
} >/dev/null 2>&1

if [ "$1" = "start" ];then
        nohup $wp/v2ray >/dev/null 2>&1 &

	iptables -t nat -A OUTPUT ! -p tcp -m comment --comment transparent-proxy -j ACCEPT
	iptables -t nat -A OUTPUT -m comment --comment transparent-proxy -m owner --uid-owner 0 -m mark --mark 65 -j ACCEPT
	iptables -t nat -A OUTPUT -p tcp -m comment --comment transparent-proxy -j REDIRECT --to-ports 1111
	iptables -t nat -A OUTPUT -p tcp -m comment --comment transparent-proxy -j ACCEPT

	ip route add local default dev lo table 1110
	ip rule add fwmark 0x1110 lookup 1110

	iptables -t mangle -A PREROUTING ! -p udp -m comment --comment transparent-proxy -j ACCEPT
	iptables -t mangle -A PREROUTING -i lo -p udp -m comment --comment transparent-proxy -m udp --dport 53 -j TPROXY --on-port 1111 --on-ip 0.0.0.0 --tproxy-mark 0x1110/0xffffffff
	iptables -t mangle -A PREROUTING -d 224.0.0.0/3 -m comment --comment transparent-proxy -j ACCEPT
	iptables -t mangle -A PREROUTING -d 203.0.113.0/24 -m comment --comment transparent-proxy -j ACCEPT
	iptables -t mangle -A PREROUTING -d 198.51.100.0/24 -m comment --comment transparent-proxy -j ACCEPT
	iptables -t mangle -A PREROUTING -d 198.18.0.0/15 -m comment --comment transparent-proxy -j ACCEPT
	iptables -t mangle -A PREROUTING -d 192.168.0.0/16 -m comment --comment transparent-proxy -j ACCEPT
	iptables -t mangle -A PREROUTING -d 192.88.99.0/24 -m comment --comment transparent-proxy -j ACCEPT
	iptables -t mangle -A PREROUTING -d 192.0.2.0/24 -m comment --comment transparent-proxy -j ACCEPT
	iptables -t mangle -A PREROUTING -d 192.0.0.0/24 -m comment --comment transparent-proxy -j ACCEPT
	iptables -t mangle -A PREROUTING -d 172.16.0.0/12 -m comment --comment transparent-proxy -j ACCEPT
	iptables -t mangle -A PREROUTING -d 169.254.0.0/16 -m comment --comment transparent-proxy -j ACCEPT
	iptables -t mangle -A PREROUTING -d 127.0.0.0/8 -m comment --comment transparent-proxy -j ACCEPT
	iptables -t mangle -A PREROUTING -d 100.64.0.0/10 -m comment --comment transparent-proxy -j ACCEPT
	iptables -t mangle -A PREROUTING -d 10.0.0.0/8 -m comment --comment transparent-proxy -j ACCEPT
	iptables -t mangle -A PREROUTING -d 0.0.0.0/8 -m comment --comment transparent-proxy -j ACCEPT
	iptables -t mangle -A PREROUTING -i lo -p udp -m comment --comment transparent-proxy -j TPROXY --on-port 1111 --on-ip 0.0.0.0 --tproxy-mark 0x1110/0xffffffff
	iptables -t mangle -A PREROUTING -p udp -m comment --comment transparent-proxy -j ACCEPT
	iptables -t mangle -A OUTPUT ! -p udp -m comment --comment transparent-proxy -j ACCEPT
	iptables -t mangle -A OUTPUT -m comment --comment transparent-proxy -m owner --uid-owner 0 -m mark --mark 65 -j ACCEPT
	iptables -t mangle -A OUTPUT -p udp -m comment --comment transparent-proxy -j MARK --set-xmark 0x1110/0xffffffff
	iptables -t mangle -A OUTPUT -p udp -m comment --comment transparent-proxy -j ACCEPT

	if command -v systemctl >/dev/null;then
		echo -e "[Unit]\nDescription=$(readlink -f $0)\nAfter=network.target\n\n[Service]\nType=forking\nExecStart=$(readlink -f $0) start\nRestart=always\n\n[Install]\nWantedBy=multi-user.target" > /etc/systemd/system/transparent-proxy.service
		systemctl daemon-reload >/dev/null 2>&1
		systemctl enable transparent-proxy.service >/dev/null 2>&1
        elif [ -e "/etc/rc.local" ];then
                tmp_echo=$(grep -v "^exit" /etc/rc.local)
                echo "$tmp_echo" > /etc/rc.local
                echo "$(readlink -f $0) start" >> /etc/rc.local
                echo "exit 0" >> /etc/rc.local
        fi
fi

